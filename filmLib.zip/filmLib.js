"use strict";
const dayjs= require("dayjs");
let now=dayjs().format();

function Film(id,title,favorite,date,rating)
{
    this.id=id;
    this.title=title;
    this.favorite=(favorite)? favorite : false;
    this.date=date;
    this.rating=(rating>=1 && rating<=5)? rating : undefined;
    this.printFilm= function(){return `Id: ${this.id} Title: ${this.title} Favourite: ${this.favorite} Watch date:  ${this.date}, Score: ${this.rating} `}

}

function FilmLibrary()
{
    this.list=[];
    this.addNewFilm=(e)=> this.list.push(e); //ho così aggiunto un metodo per film nella list 
    

    this.listByDate= ()=> {
        return [...this.list].sort((a,b)=>(a.date!=undefined && b.date!=undefined)? a.date.isAfter(b.date) ? 1 : -1 : -1);   
    }
    
    this.deleteFilm =(id) => {
        const index=this.list.findIndex((e)=>e.id===id);
        this.list.splice(index,1);
    }

    this.resetWatchDate=()=> 
    {
        this.list.forEach((e)=>(e.date!=undefined)? e.date=undefined : e.date=undefined);
    }

    this.selectScored=()=>
    {
       let ScoredMovied= this.list.filter((e)=> e.rating!=undefined);       
       ScoredMovied.sort((a,b)=>(a.score-b.score))
       return ScoredMovied;
    }
}

const film1 = new Film(1,"Pulp Fiction",true,dayjs('2023-03-10'),5);
const film2 = new Film(2,"21 Grams",true,dayjs('2023-03-12'),4);
const film3 = new Film(3,"Star Wars",false);

const f=new FilmLibrary();

f.addNewFilm(film1);
f.addNewFilm(film2);
f.addNewFilm(film3);
console.log("***** List of films *****");
f.list.forEach((e)=>console.log(e.printFilm()));
console.log("***** List of ordered *****");
f.listByDate().forEach((e)=>console.log(e.printFilm()));
f.deleteFilm(2);
console.log("***** List of films Deleted *****");
f.list.forEach((e)=>console.log(e.printFilm()));
console.log("***** List of films Reset Date *****");
f.resetWatchDate();
f.list.forEach((e)=>console.log(e.printFilm()));
console.log("***** Films filtered, only the rated ones *****");
f.selectScored().forEach((e)=>console.log(e.printFilm()));




